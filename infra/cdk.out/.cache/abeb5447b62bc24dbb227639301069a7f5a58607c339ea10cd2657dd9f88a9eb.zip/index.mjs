// ../functions/notification/handler.ts
import { randomUUID } from "node:crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  BatchWriteCommand,
  DynamoDBDocumentClient,
  QueryCommand
} from "@aws-sdk/lib-dynamodb";
function isSubscribed(prefs, workflowId) {
  return prefs?.workflowId === "all" || prefs?.workflowId === workflowId;
}
function chunkItems(items, size) {
  const chunks = [];
  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size));
  }
  return chunks;
}
function createNotificationHandler(deps) {
  const now = deps.clock ?? (() => /* @__PURE__ */ new Date());
  const uuid = deps.uuid ?? randomUUID;
  return async (event) => {
    const createdAt = now().toISOString();
    const { tenantId, workflowId, runId } = event.detail;
    const users = await deps.dynamoClient.send(
      new QueryCommand({
        TableName: deps.mainTableName,
        KeyConditionExpression: "PK = :pk AND begins_with(SK, :sk)",
        ExpressionAttributeValues: {
          ":pk": `TENANT#${tenantId}`,
          ":sk": "USER#"
        }
      })
    );
    const notifications = (users.Items ?? []).filter((user) => isSubscribed(user.notificationPrefs, workflowId)).map((user) => {
      const notificationId = uuid();
      return {
        PutRequest: {
          Item: {
            PK: `USER#${user.userId}`,
            SK: `NOTIFICATION#${createdAt}#${notificationId}`,
            type: "RUN_FAILED",
            workflowId,
            runId,
            workflowName: event.detail.workflowName,
            failedStepName: event.detail.failedStepName,
            read: false,
            createdAt
          }
        }
      };
    });
    for (const batch of chunkItems(notifications, 25)) {
      await deps.dynamoClient.send(
        new BatchWriteCommand({
          RequestItems: {
            [deps.mainTableName]: batch
          }
        })
      );
    }
  };
}
var dynamoClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
var handler = createNotificationHandler({
  dynamoClient,
  mainTableName: process.env.MAIN_TABLE_NAME ?? ""
});
export {
  createNotificationHandler,
  handler
};
